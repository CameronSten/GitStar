[Cameron Stenmark], [A00885373], [1C], [March 1st 2014]

This assignment is [enter percent]% complete.


------------------------
Question one (TriangleArea) status:

[Complete]
[]

------------------------
Question two (CylinderStats) status:

[complete]
[]

------------------------
Question three (Bookshelf) status:

[complete]
[]

------------------------
Question four (BoxTest) status:

[complete]
[]

------------------------
Question five (TrafficLight) status:

[complete]
[]
